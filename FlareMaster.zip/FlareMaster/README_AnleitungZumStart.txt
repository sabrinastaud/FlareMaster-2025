FlareMaster 2025 - Anleitung zum richtigen Start

Um das Programm zu starten müssen folgende Schritte ausgeführt werden:
- Öffnen Sie den Ordner "PythonCode_FlareMaster"
- Klicken Sie mit einem Rechtsklick auf die "BatchStart_FlareMaster.bat" Datei
- Wählen Sie "Bearbeiten" aus
Jetzt öffnet sich das Editor Fenster der .bat Datei

Sobald das Editor Fenster geöffnet wurde, suchen Sie nach folgender Code Zeile:
"python -m streamlit run C:\Users\User\Desktop\FlareMaster\ProgramCode_FlareMaster\PythonCode_FlareMaster\FlareAppMain.py"

- Nun müssen Sie sicherstellen, dass der Pfad in der sich der "FlareMaster" Ordner den Sie heruntergeladen haben auch wirlich korrekt ist.
  In diesem Beispiel liegt der "FlareMaster" Ordner auf dem Desktop.
  Andernfalls ändern Sie den Pfad in der sich der Ordner tatsächlich befindet.
- Speichern Sie die Änderungen (Strg+S) und schließen Sie das File

Nun können Sie wieder in den Überordner "FlareMaster wechseln 

- Sie können das FlareMaster Programm jetzt kopieren und beispielsweise auf ihren Desktop schieben
- Mit einem Doppelklick können Sie den FlareMaster nun öffnen und verwenden
- Bitte beachten Sie, dass Streamlit eine Weboberfläche ist, das CMD Feld, das sich minimiert autpmatisch beim Start des Programm öffnet, muss also während der aktiven Sitzung geöffnet bleiben.

Viel Spaß
